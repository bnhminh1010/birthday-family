# Ghi chú tham chiếu thiết kế

## Taste Skill — Leonxlnx/taste-skill

Kho tham chiếu nhấn mạnh một quy trình chống giao diện chung chung: suy luận brief, thiết lập hệ thiết kế, kiểm tra nhịp layout, typography, motion và khoảng trắng trước khi hoàn thiện. Với The Sweetest Slices, điều này củng cố lựa chọn light minimalist có tính biên tập: tránh dải badge dư thừa, cảnh hero phải có điểm tập trung rõ ràng, và mọi motion chỉ phục vụ nghi thức thắp–thổi–mở ký ức.

## Nguồn đang rà soát

Kage, MotionSites, Layers, Supahero, Loadmore, MacApp Supply, Dark Design và Three.js sẽ được dùng như dữ liệu tham khảo cho vật liệu UI, cấu trúc kể chuyện, chuyển động và cảnh 3D; không sao chép trực tiếp tài sản hay mã nguồn.

## Quan sát kiểm thử giao diện

Giao diện thực tế hiển thị hero light patisserie với bánh 3D, phần mở đầu typography editorial và điểm bắt đầu gallery đầy đủ đường quỹ đạo/lát bánh. Việc xem toàn trang dạng ảnh dài không phản ánh chính xác vùng gallery ghim theo viewport; kiểm thử cần xem ở vị trí cuộn trong trình duyệt và tương tác với các nút chọn lát.

Sau khi thay thế các ảnh sinh lỗi, dải ảnh trong gallery đã hiển thị ảnh thật; có thể kéo ngang và mở lightbox. Tại vùng gallery, lát bánh 3D tách khỏi bánh theo trạng thái chọn, không còn dùng ảnh minh họa như thành phần thay thế.

Thao tác chọn Slice 03 đã cập nhật đồng bộ tiêu đề, nội dung, reel ảnh và trạng thái tách lát bánh. Thao tác chọn một ảnh mở lightbox với nền blur, caption và nút đóng, phù hợp với luồng tương tác bắt buộc.

Nút thắp nến đã khởi động nhạc nền và cập nhật candle flames trong cảnh 3D. Khi quyền micro không được cấp, visualizer chuyển rõ ràng sang hướng dẫn chạm vào ngọn lửa; hành vi dự phòng này tránh làm gián đoạn hành trình của người dùng.

Thao tác chạm dự phòng đã tắt nến, hiển thị dòng wish reveal, liên kết mở album và confetti. Từ phần finale, nút ghi lời chúc đã mở một modal riêng với nền blur, textarea, nút lưu và mô tả rõ ràng rằng dữ liệu chỉ được lưu trên thiết bị.
