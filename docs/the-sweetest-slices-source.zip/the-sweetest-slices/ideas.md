# Định hướng thiết kế — The Sweetest Slices

## Ba hướng tiếp cận

### 1. Midnight Votive
**Giới thiệu ngắn:** Một buổi lễ sinh nhật riêng tư trong căn phòng đen obsidian, nơi ánh nến champagne trở thành nguồn sáng cảm xúc duy nhất. Trải nghiệm ưu tiên chiều sâu, chậm rãi và cảm giác chạm vào một kỷ niệm.

**Xác suất:** 0.07

### 2. Patisserie Paper Theatre
**Giới thiệu ngắn:** Một thế giới làm bánh bằng giấy thủ công, với tầng lớp cắt dán, màu kem bơ và những khung ảnh như đạo cụ sân khấu. Không khí vui tươi, mềm mại và gần gũi.

**Xác suất:** 0.04

### 3. Sunlit Film Archive
**Giới thiệu ngắn:** Một kho lưu trữ ký ức được tắm nắng kiểu analog, kết hợp hạt phim, màu sepia nhạt và bố cục biên tập. Cảm xúc đến từ sự mộc mạc thay vì hiệu ứng sân khấu.

**Xác suất:** 0.09

## Hướng được chọn: Midnight Votive

### Design Movement

**Dark Romanticism gặp nghệ thuật still-life đương đại**: không gian tối mang tính nghi lễ, vật liệu kính mờ và kim loại quý, được đánh thức bằng ánh nến ấm. Hướng này chuyển một chiếc bánh sinh nhật thành tâm điểm của câu chuyện, không phải một phần trang trí.

### Core Principles

1. **Ánh sáng kể chuyện:** ánh vàng chỉ xuất hiện để đánh dấu hành động, thành tựu và khoảnh khắc ước nguyện.
2. **Sân khấu trước, giao diện sau:** mọi điều khiển phải lùi lại để chiếc bánh, ngọn lửa và các lát ký ức luôn là nhân vật chính.
3. **Chuyển động có trọng lượng:** xoay, tách lát và mở ảnh theo quán tính nhẹ, tránh những chuyển cảnh ồn ào hoặc vô cớ.
4. **Vật liệu giàu cảm giác:** kính khói, sứ mờ, chrome champagne và ánh phản chiếu rose-quartz tạo chiều sâu mà không làm giao diện nặng nề.

### Color Philosophy

Obsidian `#090A0F` tạo một nền im lặng và sang trọng, giúp mọi nguồn sáng trở thành sự kiện. Champagne gold `#F6E05E` biểu đạt lời chúc và sự quý giá; candle amber `#FF9F43` mang hơi ấm thật của ngọn lửa; rose quartz `#F472B6` chỉ dùng như dấu vết cảm xúc hoặc phản quang, không làm màu chủ đạo. Hệ màu tập trung vào **ánh sáng phát ra từ kỷ niệm**, không phải màu sắc trang trí phủ lên kỷ niệm.

### Layout Paradigm

Trang là một **hành trình dọc theo trục nghi lễ**: đỉnh trang mở bằng bàn thờ chiếc bánh; phần giữa là vòng quay các lát bánh với một đường ký ức ngang bung ra từ mỗi lát; cuối trang tập hợp thành một trái tim ảnh bao quanh chiếc bánh hoàn chỉnh. Nội dung không tổ chức theo lưới thẻ đối xứng, mà được neo quanh một “quỹ đạo bánh” ở trung tâm và những vùng thông tin lệch có chủ ý.

### Signature Elements

1. **Candle halo:** vòng sáng gold nhiều lớp xung quanh ngọn lửa, phản hồi theo trạng thái thắp/tắt.
2. **Memory ribbon:** dải phim nằm ngang có viền kính và mã số lát bánh, trôi ra khỏi bề mặt bánh.
3. **Wish seal:** biểu tượng ngôi sao bốn cánh champagne xuất hiện trên nút, chỉ dẫn cuộn và thiệp cuối.

### Interaction Philosophy

Tương tác phải giống một nghi thức thân mật: người dùng **thắp**, **thổi**, **chạm lát bánh**, rồi **mở thư**. Nút bấm có lực hút nhẹ về con trỏ, ngọn lửa phản hồi theo micro hoặc thao tác chạm, và ảnh mở trong lightbox giúp tập trung vào một kỷ niệm mỗi lần. Các thao tác phụ như chia sẻ hoặc ghi lời chúc được báo rõ là bản trình diễn khi chưa được kết nối dịch vụ thật.

### Animation

Phần đầu dùng bokeh rất chậm và glow thở nhẹ 2,8–4 giây. Khi thắp, tia lửa di chuyển nhanh nhưng hữu hạn; phần halo mở bằng opacity và scale 0.96–1. Khi thổi tắt, ngọn lửa nghiêng theo mức âm thanh, thu nhỏ rồi biến thành khói bay lên; confetti rơi có lực và tắt dần. Các lát bánh thay đổi theo scroll bằng transform/opacity được GPU tăng tốc, với spring mềm và tôn trọng `prefers-reduced-motion`. Giao diện thường phản hồi trong 120–220ms; khoảnh khắc nghi lễ có thể kéo dài 600–900ms để cảm xúc kịp hiện diện.

### Typography System

**Cormorant Garamond** được dùng cho tiêu đề giàu cảm xúc, kiểu italic cho lời chúc và các câu ngắn trên thiệp. **Manrope** đảm trách điều khiển, nhãn và mô tả với tracking rộng, chữ hoa nhỏ cho cấp bậc. Tiêu đề có thể rất lớn và lệch trục; văn bản vận hành luôn rõ nét, không mảnh quá mức trên nền đen.

### Brand Essence

**The Sweetest Slices là trải nghiệm sinh nhật nhập vai dành cho những nhóm bạn muốn biến lời chúc và ảnh chung thành một nghi thức kỹ thuật số đáng nhớ.**

Tính cách thương hiệu: **ấm áp, tinh tế, giàu cảm xúc**.

### Brand Voice

Giọng nói nhỏ nhẹ, gợi hình và có tính mời gọi; tránh ngôn ngữ thúc ép hay sáo rỗng. Headline như một lời thì thầm, CTA như lời mời thực hiện nghi lễ.

Ví dụ: “Hãy đánh thức ngọn lửa đầu tiên.”

Ví dụ: “Mỗi lát bánh giữ lại một mùa thương.”

### Wordmark & Logo

Logo là **một lát bánh cách điệu nhìn từ trên xuống**, có vệt kem uốn thành ngôi sao bốn cánh và một chấm flame amber ở tâm; không chứa chữ. Wordmark dùng Cormorant Garamond với các ký tự giãn thoáng và một vết cắt nhỏ trên chữ “S”, gợi lát bánh được chia sẻ.

### Signature Brand Color

**Votive Gold — `#F6E05E`**: sắc vàng champagne dùng nhất quán cho ngọn lửa, điểm nhấn tương tác và dấu niêm phong lời chúc.

## Style Decisions

- **Nhịp trang:** không để lại một đoạn cuộn tối trống; mỗi nhịp phải có ít nhất một neo nghi lễ — halo, đường quỹ đạo lát bánh, dải ký ức, vật phẩm ảnh hoặc wish seal.
- **Hệ motif:** candle halo, memory ribbon và four-point wish seal là ba vật trang trí duy nhất lặp lại xuyên suốt hero, điều hướng ký ức, hành động và thiệp cuối.
- **Xử lý hình ảnh:** ảnh bánh và ký ức luôn được đặt như hiện vật analog dưới ánh nến, có phản quang glass/champagne và lớp chồng mang tính nghi lễ; không dùng như ảnh thẻ chữ nhật thông thường.

---

# Bản cập nhật định hướng — Light Minimalist

## Hướng được chọn: Soft Patisserie Gallery

### Design Movement

**Scandinavian editorial minimalism kết hợp với nghệ thuật food-still-life hiện đại.** Không gian trắng ngà như một gallery nhỏ, nơi chiếc bánh sinh nhật trông đủ thật để có thể chạm vào, còn chuyển động chỉ làm những chất liệu tinh tế hơn — kem bơ, nến, giấy ảnh và ánh nắng dịu.

### Core Principles

1. **Khoảng thở là trọng tâm:** nền cream rộng, đường nét mảnh và thành phần đặt lệch nhẹ giúp bánh luôn có không gian riêng.
2. **Chân thực, không phô diễn:** bánh phải có bề mặt kem mịn, viền frosting, cốt bánh và nến sáp rõ ràng; ánh sáng là ánh sáng phòng buổi sáng thay vì hiệu ứng glow.
3. **Chuyển động như xúc giác:** nến rung nhẹ, frosting thở rất nhỏ, lát bánh trượt theo spring mềm và ảnh nghiêng theo điểm chạm.
4. **Ít màu, đúng chỗ:** chỉ có butter yellow, cherry red rất nhỏ, pistachio green nhẹ và charcoal mềm để trải nghiệm luôn sáng nhưng không nhạt.

### Color Philosophy

Nền **porcelain `#FBF8F2`** và linen `#F2EEE5` khiến nội dung giống một quyển lưu bút cao cấp. Butter yellow `#F6D86C` được dành cho nến, số thứ tự và CTA; cherry `#D85C54` chỉ là dấu điểm trên trái anh đào hoặc đầu nến; pistachio `#9BB69A` làm nhịp nghỉ nhẹ. Chữ dùng charcoal `#282722`, không dùng đen tuyệt đối để giữ cảm giác mềm.

### Layout Paradigm

Giao diện là một **bàn tiệc trải ngang**: ở đầu trang là chiếc bánh đặt lệch trên một mặt bàn mờ; các lát ký ức nở thành những tờ card có mép giấy ngà được bố trí như phần bày biện, không có vùng ghim hoặc khoảng tối dài. Phần cuối mở thành một thiệp gấp trắng với bánh hoàn chỉnh và bộ ảnh nhỏ gọn.

### Signature Elements

1. **Butter scallop:** đường viền gợn như kem bắt bông, xuất hiện ở chân bánh, card ảnh và đường phân cách.
2. **Candle stroke:** một nét nến mảnh cùng chấm lửa butter yellow, dùng để ghi nhịp điều hướng.
3. **Cherry dot:** một chấm đỏ cherry nhỏ, chỉ dùng để đánh dấu khoảnh khắc đang hoạt động hoặc con số trọng tâm.

### Interaction Philosophy

Website không “biểu diễn” mà phản hồi dịu dàng: nút thắp nến lún nhẹ như chạm vào giấy dày; người dùng có thể thổi hoặc chạm vào lửa; mỗi lát bánh mở reel ảnh bằng hiệu ứng trượt ngắn có trọng lượng. Thao tác chia sẻ và ghi lời chúc vẫn được thông báo rõ ràng khi là trải nghiệm trong phiên xem.

### Animation

Đa số animation kéo dài 160–350ms, dùng opacity, transform và spring mềm. Cả bánh có chuyển động bob 3px/4 giây; lửa nến thay đổi scale/rotation rất nhỏ theo micro; confetti chuyển thành những mẩu giấy màu butter, cherry và pistachio ít hạt hơn. Tất cả hiệu ứng không thiết yếu được tắt theo `prefers-reduced-motion`.

### Typography System

**DM Serif Display** làm heading thanh lịch, có khoảng cách vừa phải thay vì dramatic italic lớn. **Manrope** được giữ lại cho body/UI ở cỡ dễ đọc; nhãn ngắn dùng uppercase nhẹ với tracking nhỏ. Hệ chữ không quá mảnh, ưu tiên tinh gọn và dịu mắt trên nền sáng.

### Brand Essence

**The Sweetest Slices là một album sinh nhật tương tác tối giản, dành cho những người muốn kỷ niệm bằng ký ức gần gũi thay vì hiệu ứng ồn ào.**

Tính cách thương hiệu: **tươi sáng, tinh tế, thân mật**.

### Brand Voice

Giọng nói ngắn, ấm và sáng sủa, giống một lời nhắn viết tay bên chiếc bánh. Ví dụ: “Thắp một điều ước nhỏ.” và “Cắt ra một lát của hôm nay.”

### Wordmark & Logo

Biểu tượng là một **lát bánh kem tối giản** với đường scallop butter-yellow, một nến mảnh và chấm cherry đỏ. Wordmark dùng serif thanh lịch, nhưng giao diện chủ yếu dùng biểu tượng độc lập và tên thương hiệu cỡ nhỏ.

### Signature Brand Color

**Butter Note — `#F6D86C`**: sắc vàng bơ dịu, được dùng cho nến, CTA và các điểm đánh dấu quan trọng.
