# Công việc — Light Minimalist Redesign

- [x] Xác lập hướng thiết kế light minimalist và cập nhật quyết định trong `ideas.md`.
- [x] Tạo bộ ảnh hero, ảnh ký ức và biểu tượng thương hiệu phù hợp nền sáng.
- [x] Thiết kế lại cảnh bánh 3D với vật liệu bánh kem chân thực hơn và chuyển động tinh tế.
- [x] Thay giao diện tối bằng hệ màu, nhịp bố cục và typography sáng tối giản.
- [x] Kiểm tra TypeScript, bản dựng sản xuất và giao diện trên desktop/mobile.
- [ ] Lưu checkpoint và bàn giao phiên bản đã cập nhật.

## Bàn giao mã nguồn

- [ ] Đóng gói mã nguồn website hiện tại thành tệp ZIP có thể tải xuống và chỉnh sửa độc lập.

## Ràng buộc ưu tiên từ prompt gốc

- [x] Bảo toàn Hero Candle Lighting Stage: bánh 3D trên pedestal, CTA, spark/light event, nhạc, visualizer micro và thao tác chạm thay thế.
- [x] Bảo toàn Blow Detector: theo dõi RMS từ micro, lửa phản ứng theo cường độ, smoke, flash, confetti và wish reveal sau khi thổi tắt.
- [x] Bảo toàn Slice-by-Slice Gallery: khung 100vh ghim theo cuộn, 5 lát bánh tách ra, badge từng lát và memory ribbon parallax ngang.
- [x] Bảo toàn tương tác ảnh: glass reflection/3D tilt, zoom, date stamp, caption và lightbox nền blur.
- [x] Bảo toàn Finale: mosaic Polaroid hình tim quanh bánh hoàn chỉnh, wish card glassmorphic, chuyển đổi âm thanh và ba hành động cuối.

## Tham chiếu thiết kế

- [x] Rà soát các nguồn đã cung cấp và chuyển hóa có chọn lọc các nguyên tắc về chuyển động, vật liệu giao diện, chiều sâu 3D và nhịp kể chuyện vào giao diện light minimalist.

## Tiêu chí production-ready

- [x] Loại bỏ mọi bố cục rập khuôn, khoảng đệm trống vô nghĩa và tương tác chỉ mang tính trang trí; mỗi thành phần phải phục vụ mạch kể chuyện hoặc thao tác người dùng.
- [x] Hoàn thiện trạng thái thành công, từ chối quyền micro, thiết bị không hỗ trợ và các CTA dự phòng trên desktop/mobile.
