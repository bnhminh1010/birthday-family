/** Soft Patisserie Gallery: a paper-and-glass memory ribbon, tactile but light, never a generic card rail. */
import { motion } from "framer-motion";
import { Expand, MoveRight } from "lucide-react";
import { useRef } from "react";

export type MemoryPhoto = { image: string; alt: string; date: string; caption: string; };

export default function MemoryReel({ photos, onOpen }: { photos: MemoryPhoto[]; onOpen: (photo: MemoryPhoto) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  return (
    <div className="memory-reel-wrap">
      <div className="memory-reel-heading"><span className="candle-stroke" /> Kéo dải phim <MoveRight size={15} /></div>
      <motion.div ref={ref} className="memory-reel" drag="x" dragConstraints={{ left: -660, right: 0 }} dragElastic={0.08}>
        {photos.map((photo, index) => (
          <motion.button key={`${photo.date}-${index}`} type="button" className="memory-card" onClick={() => onOpen(photo)} whileHover={{ y: -8, rotate: index % 2 ? 1.5 : -1.5 }} whileTap={{ scale: 0.98 }}>
            <span className="memory-photo-frame"><img src={photo.image} alt={photo.alt} draggable={false} /><i /></span>
            <span className="memory-meta"><b>{photo.date}</b><em>{photo.caption}</em></span>
            <span className="expand-mark"><Expand size={14} /></span>
          </motion.button>
        ))}
      </motion.div>
    </div>
  );
}
