/** Soft Patisserie Gallery: vertical movement selects one of five real cake slices; each selection unfolds a horizontal photo ribbon. */
import { motion, useMotionValueEvent, useScroll } from "framer-motion";
import { ChevronDown, Sparkle } from "lucide-react";
import { useRef } from "react";
import CakeScene from "./CakeScene";
import MemoryReel, { type MemoryPhoto } from "./MemoryReel";

export type SliceMemory = { number: string; title: string; label: string; text: string; photoCount: number; hue: string; photos: MemoryPhoto[]; };

const photoSet: MemoryPhoto[] = [
  { image: "https://images.unsplash.com/photo-1513159446162-54eb8bdaa79b?auto=format&fit=crop&w=1200&q=86", alt: "Chiếc bánh sinh nhật nhỏ trên bàn", date: "2008", caption: "Một điều ước bé xíu" },
  { image: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1200&q=86", alt: "Con đường cho một chuyến đi", date: "2016", caption: "Lên đường cùng nhau" },
  { image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=86", alt: "Cà phê buổi sáng", date: "2020", caption: "Ngày thường rất ngọt" },
  { image: "https://images.unsplash.com/photo-1506459225024-1428097a7e18?auto=format&fit=crop&w=1200&q=85", alt: "Khoảnh khắc bạn bè ngoài trời", date: "2022", caption: "Cả nhóm ở đây" },
  { image: "https://images.unsplash.com/photo-1527529482837-4698179dc6ce?auto=format&fit=crop&w=1200&q=85", alt: "Bữa tiệc bạn bè vui vẻ", date: "Tonight", caption: "Vì bạn, hôm nay" },
];

export const sliceMemories: SliceMemory[] = [
  { number: "01", title: "Những chương đầu", label: "Childhood", text: "Những bàn tay bé, những chiếc bánh vụng về, và niềm vui chưa từng cần lý do.", photoCount: 6, hue: "#F6D86C", photos: [photoSet[0], photoSet[3], photoSet[2]] },
  { number: "02", title: "Đi xa để về gần", label: "Travels", text: "Có những chuyến đi khiến ta nhận ra mình luôn có một nơi để trở về.", photoCount: 4, hue: "#9BB69A", photos: [photoSet[1], photoSet[3], photoSet[0]] },
  { number: "03", title: "Những ngày rất ngọt", label: "Daily joys", text: "Một tách cà phê, một lần hẹn muộn, một buổi sáng không cần vội.", photoCount: 8, hue: "#F6D86C", photos: [photoSet[2], photoSet[0], photoSet[3]] },
  { number: "04", title: "Điều mình đã xây", label: "Milestones", text: "Từng bước nhỏ được gom lại thành một lý do rất đẹp để mỉm cười.", photoCount: 5, hue: "#D85C54", photos: [photoSet[3], photoSet[1], photoSet[2]] },
  { number: "05", title: "Hôm nay, có chúng ta", label: "Celebration", text: "Một lát bánh của hiện tại, dành cho tất cả những người vẫn chọn ở cạnh nhau.", photoCount: 9, hue: "#D85C54", photos: [photoSet[4], photoSet[2], photoSet[0]] },
];

export default function ScrollyGallery({ activeSlice, onActiveChange, onOpenPhoto }: { activeSlice: number; onActiveChange: (index: number) => void; onOpenPhoto: (photo: MemoryPhoto) => void; }) {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end end"] });
  useMotionValueEvent(scrollYProgress, "change", (progress) => {
    const index = Math.max(0, Math.min(4, Math.round(progress * 4)));
    if (index !== activeSlice) onActiveChange(index);
  });
  const memory = sliceMemories[activeSlice];

  return (
    <section ref={sectionRef} id="memories" className="scrolly-section" aria-label="Ký ức theo từng lát bánh">
      <div className="gallery-sticky">
        <span className="gallery-scallop scallop-top" aria-hidden="true" />
        <div className="gallery-heading"><span className="section-kicker"><Sparkle size={13} /> slice by slice</span><h2>Cắt ra một lát<br /><em>của hôm nay.</em></h2></div>
        <div className="slice-path" aria-hidden="true"><span /><span /><span /><span /><span /></div>
        <div className="gallery-cake"><CakeScene lit={false} extinguished activeSlice={activeSlice} variant="gallery" /></div>
        <motion.article key={memory.number} className="slice-story" initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.36, ease: [0.23, 1, 0.32, 1] }}>
          <p className="slice-count"><b style={{ background: memory.hue }} /> Slice {memory.number} · {memory.photoCount} ảnh</p>
          <h3>{memory.title}</h3>
          <p>{memory.text}</p>
          <span className="story-caption">{memory.label}</span>
        </motion.article>
        <div className="slice-tabs" aria-label="Các lát ký ức">
          {sliceMemories.map((slice, index) => <button key={slice.number} type="button" className={index === activeSlice ? "active" : ""} onClick={() => onActiveChange(index)}><i style={{ background: slice.hue }} /><span>{slice.number}</span></button>)}
        </div>
        <div className="gallery-reel"><MemoryReel photos={memory.photos} onOpen={onOpenPhoto} /></div>
        <p className="gallery-scroll-cue"><ChevronDown size={15} /> Cuộn để khám phá lát tiếp theo</p>
      </div>
    </section>
  );
}
