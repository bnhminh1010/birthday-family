/**
 * Soft Patisserie Gallery: lifelike vanilla cake materials, butter scallops, small candle flames,
 * and controlled spring-like slice separation. The scene stays bright, tactile, and uncluttered.
 */
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";

type CakeSceneProps = {
  lit: boolean;
  extinguished: boolean;
  intensity?: number;
  activeSlice?: number;
  variant?: "stage" | "gallery" | "finale";
  onFlameClick?: () => void;
};

const sliceCount = 5;
const candles = [
  [-0.34, -0.06],
  [0, 0.11],
  [0.34, -0.04],
] as const;

function FrostingScallops({ radius, y, count = 36 }: { radius: number; y: number; count?: number }) {
  return (
    <group>
      {Array.from({ length: count }, (_, index) => {
        const angle = (index / count) * Math.PI * 2;
        return (
          <mesh key={index} position={[Math.cos(angle) * radius, y + Math.sin(index * 0.7) * 0.012, Math.sin(angle) * radius]} castShadow>
            <sphereGeometry args={[0.075, 12, 12]} />
            <meshPhysicalMaterial color="#FFF8E7" roughness={0.48} clearcoat={0.18} />
          </mesh>
        );
      })}
    </group>
  );
}

function CandleFlame({ position, lit, extinguished, intensity, onFlameClick }: { position: readonly [number, number]; lit: boolean; extinguished: boolean; intensity: number; onFlameClick?: () => void }) {
  const flameRef = useRef<THREE.Mesh>(null);
  const smokeRef = useRef<THREE.Group>(null);
  const material = useMemo(() => new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    uniforms: { uTime: { value: 0 }, uIntensity: { value: 0 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `varying vec2 vUv; uniform float uTime; uniform float uIntensity; void main(){ float x = abs(vUv.x - 0.5); float taper = smoothstep(0.5, 0.04, x + (1.0-vUv.y)*0.24 + sin(uTime*15.0+vUv.y*8.0)*0.018*uIntensity); float core = smoothstep(0.5, 0.08, abs(vUv.x-0.5)+(1.0-vUv.y)*0.35); vec3 col = mix(vec3(1.0,0.46,0.05),vec3(1.0,0.94,0.43),vUv.y); gl_FragColor = vec4(mix(col,vec3(1.0,0.99,0.82),core*0.72), taper*0.96); }`,
  }), []);

  useFrame(({ clock }) => {
    material.uniforms.uTime.value = clock.getElapsedTime();
    material.uniforms.uIntensity.value = intensity;
    if (flameRef.current) {
      const breath = 1 + Math.sin(clock.getElapsedTime() * 15) * 0.06 + intensity * 0.36;
      flameRef.current.scale.set(0.28 + intensity * 0.08, 0.45 * breath, 0.28 + intensity * 0.08);
      flameRef.current.rotation.z = Math.sin(clock.getElapsedTime() * 12) * (0.09 + intensity * 0.32);
      flameRef.current.visible = lit && !extinguished;
    }
    if (smokeRef.current) {
      smokeRef.current.visible = extinguished;
      smokeRef.current.position.y = 1.27 + (clock.getElapsedTime() % 2.6) * 0.13;
      smokeRef.current.rotation.y = clock.getElapsedTime() * 0.45;
    }
  });

  return (
    <group position={[position[0], 1.02, position[1]]}>
      <mesh castShadow>
        <cylinderGeometry args={[0.038, 0.045, 0.58, 20]} />
        <meshPhysicalMaterial color="#F6D86C" roughness={0.31} clearcoat={0.72} />
      </mesh>
      <mesh position={[0, 0.35, 0]}><cylinderGeometry args={[0.01, 0.01, 0.12, 8]} /><meshStandardMaterial color="#352D23" /></mesh>
      <pointLight color="#FFD56A" intensity={lit && !extinguished ? 2.8 + intensity * 5 : 0} distance={4.8} decay={2} />
      <mesh ref={flameRef} position={[0, 0.45, 0]} onClick={onFlameClick} onPointerOver={() => { document.body.style.cursor = "pointer"; }} onPointerOut={() => { document.body.style.cursor = "auto"; }}>
        <planeGeometry args={[1, 1, 1, 1]} />
        <primitive object={material} attach="material" />
      </mesh>
      <group ref={smokeRef} position={[0, 0.44, 0]}>
        {[0, 1, 2].map((particle) => <mesh key={particle} position={[(particle - 1) * 0.035, particle * 0.105, 0]}><sphereGeometry args={[0.035 + particle * 0.018, 12, 12]} /><meshBasicMaterial color="#B8B3AA" transparent opacity={0.24 - particle * 0.055} /></mesh>)}
      </group>
    </group>
  );
}

function CakeSlice({ index, activeSlice, variant }: { index: number; activeSlice?: number; variant: NonNullable<CakeSceneProps["variant"]> }) {
  const groupRef = useRef<THREE.Group>(null);
  const segment = (Math.PI * 2) / sliceCount;
  const start = index * segment + 0.026;
  const middle = start + segment / 2;
  const active = activeSlice === index;
  const distance = variant === "gallery" ? (active ? 1.12 : 0.13) : 0;

  useFrame((_, delta) => {
    if (!groupRef.current) return;
    groupRef.current.position.x = THREE.MathUtils.damp(groupRef.current.position.x, Math.cos(middle) * distance, 3.8, delta);
    groupRef.current.position.z = THREE.MathUtils.damp(groupRef.current.position.z, Math.sin(middle) * distance, 3.8, delta);
    groupRef.current.position.y = THREE.MathUtils.damp(groupRef.current.position.y, active ? 0.09 : 0, 3.8, delta);
  });

  const baseColor = variant === "finale" ? "#E8BC5F" : "#E9B970";
  return (
    <group ref={groupRef}>
      <mesh castShadow receiveShadow position={[0, -0.22, 0]}><cylinderGeometry args={[1.45, 1.5, 0.42, 48, 1, false, start, segment - 0.055]} /><meshPhysicalMaterial color={baseColor} roughness={0.82} /></mesh>
      <mesh castShadow position={[0, 0.05, 0]}><cylinderGeometry args={[1.46, 1.46, 0.18, 48, 1, false, start, segment - 0.055]} /><meshPhysicalMaterial color="#FFF8E7" roughness={0.45} clearcoat={0.2} /></mesh>
      <mesh castShadow position={[0, 0.2, 0]}><cylinderGeometry args={[1.39, 1.44, 0.2, 48, 1, false, start, segment - 0.055]} /><meshPhysicalMaterial color="#F2D7A2" roughness={0.74} /></mesh>
    </group>
  );
}

function CakeModel({ lit, extinguished, intensity = 0, activeSlice, variant = "stage", onFlameClick }: CakeSceneProps) {
  const groupRef = useRef<THREE.Group>(null);
  const cherryPositions = [[-0.54, 0.23], [0.53, 0.31], [0.13, -0.46]] as const;

  useFrame(({ clock }, delta) => {
    if (!groupRef.current) return;
    const desiredRotation = activeSlice === undefined ? Math.sin(clock.getElapsedTime() * 0.32) * 0.12 : -activeSlice * ((Math.PI * 2) / sliceCount) + 0.64;
    groupRef.current.rotation.y = THREE.MathUtils.damp(groupRef.current.rotation.y, desiredRotation, 1.8, delta);
    groupRef.current.position.y = Math.sin(clock.getElapsedTime() * 0.8) * 0.025;
  });

  return (
    <group ref={groupRef} position={[0, -0.3, 0]}>
      <mesh position={[0, -0.7, 0]} castShadow receiveShadow><cylinderGeometry args={[1.88, 1.72, 0.22, 64]} /><meshPhysicalMaterial color="#F4F0E8" roughness={0.28} clearcoat={0.7} /></mesh>
      <mesh position={[0, -0.84, 0]} receiveShadow><cylinderGeometry args={[2.13, 2.13, 0.1, 64]} /><meshPhysicalMaterial color="#DED9CF" roughness={0.48} /></mesh>
      {Array.from({ length: sliceCount }, (_, index) => <CakeSlice key={index} index={index} activeSlice={activeSlice} variant={variant} />)}
      <FrostingScallops radius={1.46} y={0.11} />
      <mesh position={[0, 0.45, 0]} castShadow><cylinderGeometry args={[0.86, 0.94, 0.48, 48]} /><meshPhysicalMaterial color="#FFF8E7" roughness={0.42} clearcoat={0.22} /></mesh>
      <mesh position={[0, 0.73, 0]} castShadow><cylinderGeometry args={[0.89, 0.89, 0.09, 48]} /><meshPhysicalMaterial color="#FFFDF6" roughness={0.36} clearcoat={0.3} /></mesh>
      <FrostingScallops radius={0.9} y={0.62} count={25} />
      {cherryPositions.map(([x, z], index) => <group key={index} position={[x, 0.84, z]}><mesh castShadow><sphereGeometry args={[0.105, 18, 18]} /><meshPhysicalMaterial color="#D85C54" roughness={0.32} clearcoat={0.72} /></mesh><mesh position={[0.05, 0.11, 0]} rotation={[0.8, 0.3, 0.5]}><cylinderGeometry args={[0.011, 0.011, 0.16, 8]} /><meshBasicMaterial color="#839E75" /></mesh></group>)}
      {candles.map((position, index) => <CandleFlame key={index} position={position} lit={lit} extinguished={extinguished} intensity={intensity} onFlameClick={onFlameClick} />)}
    </group>
  );
}

export default function CakeScene(props: CakeSceneProps) {
  return (
    <div className="cake-canvas" aria-label="Bánh sinh nhật 3D có thể tương tác">
      <Canvas dpr={[1, 1.5]} shadows camera={{ position: [0, 1.55, 5.7], fov: 35 }} gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}>
        <ambientLight intensity={1.5} color="#FFF6E0" />
        <directionalLight position={[-4, 6, 5]} intensity={3.4} color="#FFF7E3" castShadow />
        <directionalLight position={[3, 1, -2]} intensity={1.1} color="#E7F0D8" />
        <CakeModel {...props} />
        <ContactShadows position={[0, -0.94, 0]} opacity={0.24} scale={5.5} blur={2.5} far={3} color="#8E8370" />
        <OrbitControls enablePan={false} enableZoom={false} minPolarAngle={1.18} maxPolarAngle={2.0} />
      </Canvas>
    </div>
  );
}
