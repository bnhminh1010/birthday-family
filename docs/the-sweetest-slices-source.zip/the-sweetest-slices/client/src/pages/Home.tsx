/**
 * Soft Patisserie Gallery: a light, editorial birthday ritual. Every interaction serves the story:
 * light the candles, make a wish, move through five slices, then leave a note in the final card.
 */
import confetti from "canvas-confetti";
import { AnimatePresence, motion } from "framer-motion";
import { Howl } from "howler";
import Lenis from "lenis";
import { AudioLines, ChevronDown, Flame, Heart, Mail, Pause, Play, Share2, Sparkles, Volume2, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import CakeScene from "@/components/CakeScene";
import MemoryReel, { type MemoryPhoto } from "@/components/MemoryReel";
import ScrollyGallery, { sliceMemories } from "@/components/ScrollyGallery";
import { useBlowDetector } from "@/hooks/useBlowDetector";

const heroImage = "/manus-storage/light-slices-cake-reference_d69eef62.jpg";
const musicUrl = "/manus-storage/the-sweetest-slices-lofi_080a5336.mp3";

function MagneticButton({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  const ref = useRef<HTMLButtonElement>(null);
  const handleMove = (event: React.PointerEvent<HTMLButtonElement>) => {
    const button = ref.current;
    const rect = button?.getBoundingClientRect();
    if (!button || !rect || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const x = (event.clientX - rect.left - rect.width / 2) * 0.12;
    const y = (event.clientY - rect.top - rect.height / 2) * 0.16;
    button.style.transform = `translate(${x}px, ${y}px)`;
  };
  return <button ref={ref} type="button" className="light-button" onPointerMove={handleMove} onPointerLeave={() => { if (ref.current) ref.current.style.transform = ""; }} onClick={onClick}>{children}</button>;
}

export default function Home() {
  const [candleLit, setCandleLit] = useState(false);
  const [extinguished, setExtinguished] = useState(false);
  const [activeSlice, setActiveSlice] = useState(0);
  const [selectedPhoto, setSelectedPhoto] = useState<MemoryPhoto | null>(null);
  const [showNote, setShowNote] = useState(false);
  const [note, setNote] = useState(() => localStorage.getItem("sweetest-slices-note") || "");
  const [toast, setToast] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const soundRef = useRef<Howl | null>(null);
  const celebrationRef = useRef(false);

  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.075, smoothWheel: true, wheelMultiplier: 0.8, touchMultiplier: 1.15 });
    let animationFrame = 0;
    const loop = (time: number) => { lenis.raf(time); animationFrame = requestAnimationFrame(loop); };
    animationFrame = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(animationFrame); lenis.destroy(); soundRef.current?.unload(); };
  }, []);

  const startSound = () => {
    if (!soundRef.current) soundRef.current = new Howl({ src: [musicUrl], loop: true, volume: 0, html5: true });
    if (!soundRef.current.playing()) soundRef.current.play();
    soundRef.current.fade(0, 0.18, 1250);
    setIsPlaying(true);
  };
  const toggleSound = () => {
    if (!soundRef.current || !soundRef.current.playing()) startSound();
    else { soundRef.current.pause(); setIsPlaying(false); }
  };
  const celebrate = useCallback(() => {
    if (celebrationRef.current) return;
    celebrationRef.current = true;
    setExtinguished(true);
    soundRef.current?.fade(0.18, 0.26, 900);
    confetti({ particleCount: 72, spread: 55, startVelocity: 20, gravity: 0.72, scalar: 0.72, origin: { y: 0.42 }, colors: ["#F6D86C", "#D85C54", "#9BB69A", "#FFF8E7"] });
    window.setTimeout(() => confetti({ particleCount: 44, spread: 90, startVelocity: 15, gravity: 0.82, scalar: 0.62, origin: { x: 0.55, y: 0.36 }, colors: ["#F6D86C", "#D85C54", "#9BB69A"] }), 160);
  }, []);
  const { intensity, status } = useBlowDetector({ enabled: candleLit && !extinguished, onBlowOut: celebrate, threshold: 0.1 });
  const lightCandles = () => { setCandleLit(true); setExtinguished(false); celebrationRef.current = false; startSound(); };
  const replay = () => { setCandleLit(false); setExtinguished(false); celebrationRef.current = false; setActiveSlice(0); soundRef.current?.stop(); setIsPlaying(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const shareExperience = async () => {
    const data = { title: "The Sweetest Slices", text: "Một lát bánh của hôm nay, dành cho bạn.", url: window.location.href };
    try { if (navigator.share) await navigator.share(data); else { await navigator.clipboard.writeText(window.location.href); setToast("Đã sao chép liên kết."); } } catch { /* native share was dismissed */ }
  };
  const saveNote = (event: React.FormEvent) => { event.preventDefault(); localStorage.setItem("sweetest-slices-note", note.trim()); setShowNote(false); setToast(note.trim() ? "Lời chúc đã được lưu trên thiết bị này." : "Bạn có thể viết một lời chúc bất cứ lúc nào."); };
  const micText = status === "listening" ? "Đang lắng nghe làn gió của bạn" : status === "denied" ? "Không sao — chạm ngọn lửa để thổi tắt" : status === "unsupported" ? "Chạm ngọn lửa để thực hiện điều ước" : "Cho phép micro hoặc chạm ngọn lửa";
  const finalePhotos = sliceMemories.flatMap((slice) => slice.photos).slice(0, 8);

  return <main className="sweet-app">
    <header className="site-header"><a href="#top" className="brand-lockup" aria-label="The Sweetest Slices"><span className="brand-seal" aria-hidden="true"><i /><b /></span><span>The Sweetest<br /><em>Slices</em></span></a><p className="header-note"><i /> a birthday archive</p><div className="header-actions"><button type="button" onClick={toggleSound} aria-label={isPlaying ? "Tạm dừng nhạc" : "Phát nhạc"}>{isPlaying ? <Pause size={14} fill="currentColor" /> : <Volume2 size={14} />}</button><a href="#memories">Ký ức <ChevronDown size={14} /></a></div></header>
    <section id="top" className={`hero-stage ${candleLit ? "is-lit" : ""} ${extinguished ? "is-extinguished" : ""}`}>
      <img className="hero-still-life" src={heroImage} alt="Bánh sinh nhật vanilla trên đế sứ" />
      <div className="hero-wash" /><span className="hero-scallop" aria-hidden="true" />
      <div className="hero-copy"><p className="section-kicker"><Sparkles size={13} /> a small birthday ritual</p><h1>Một lát ngọt ngào<br /><em>của hôm nay.</em></h1><p>Thắp nến, thực hiện điều ước, rồi mở ra những điều đã làm bạn trở thành bạn.</p>{!candleLit && <MagneticButton onClick={lightCandles}><Flame size={16} fill="currentColor" /> Thắp những ngọn nến <span>→</span></MagneticButton>}</div>
      <div className="hero-cake"><CakeScene lit={candleLit} extinguished={extinguished} intensity={intensity} onFlameClick={candleLit && !extinguished ? celebrate : undefined} /></div>
      <AnimatePresence>{candleLit && !extinguished && <motion.div className="blow-badge" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}><div className="audio-bars">{[0, 1, 2, 3].map((item) => <i key={item} style={{ height: `${7 + intensity * (13 + item * 5)}px` }} />)}</div><div><strong><AudioLines size={14} /> Thổi vào micro</strong><small>{micText}</small></div><button type="button" onClick={celebrate} aria-label="Chạm để thổi tắt nến"><Flame size={15} /></button></motion.div>}</AnimatePresence>
      <AnimatePresence>{extinguished && <motion.div className="wish-reveal" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.65 }}><span className="candle-stroke" /><p>Make a wish</p><h2>Every slice holds<br /><em>a memory.</em></h2><a href="#memories">Mở album ký ức <ChevronDown size={16} /></a></motion.div>}</AnimatePresence>
      {!extinguished && <p className="hero-scroll-cue">Cuộn để xem album <ChevronDown size={16} /></p>}
    </section>
    <section className="intro-section"><span className="mini-cake" aria-hidden="true"><i /><b /><b /><b /></span><p>Một album sinh nhật, được cắt thành năm lát.</p><h2>Mỗi lát giữ lại<br /><em>một phần rất bạn.</em></h2></section>
    <ScrollyGallery activeSlice={activeSlice} onActiveChange={setActiveSlice} onOpenPhoto={setSelectedPhoto} />
    <section className="finale-section"><div className="finale-photo-fan" aria-hidden="true">{finalePhotos.map((photo, index) => <img key={`${photo.date}-${index}`} className={`fan-${index + 1}`} src={photo.image} alt="" />)}</div><div className="finale-cake"><CakeScene lit={false} extinguished variant="finale" /></div><motion.article className="wish-letter" initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.45 }} transition={{ duration: 0.62, ease: [0.23, 1, 0.32, 1] }}><span className="letter-cherry" /><p className="section-kicker"><Heart size={12} fill="currentColor" /> from all of us</p><h2>Happy Birthday,<br /><em>dear you.</em></h2><p className="letter-copy">Mong một năm mới của bạn đủ bình yên để chậm lại, đủ rộng rãi để khám phá, và luôn có người cùng ăn thêm một lát bánh.</p><p className="letter-sign">Với tất cả yêu thương.</p><div className="letter-actions"><button type="button" onClick={replay}><Play size={14} fill="currentColor" /> Xem lại</button><button type="button" onClick={shareExperience}><Share2 size={14} /> Chia sẻ</button><button type="button" onClick={() => setShowNote(true)}><Mail size={14} /> Ghi lời chúc</button></div></motion.article><p className="finale-footer"><span className="brand-seal" aria-hidden="true"><i /><b /></span> The sweetest moments are the ones we share.</p></section>
    <AnimatePresence>{selectedPhoto && <motion.div className="lightbox" role="dialog" aria-modal="true" aria-label="Ảnh kỷ niệm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedPhoto(null)}><motion.figure initial={{ opacity: 0, scale: 0.97, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }} onClick={(event) => event.stopPropagation()}><img src={selectedPhoto.image} alt={selectedPhoto.alt} /><figcaption><b>{selectedPhoto.date}</b><em>{selectedPhoto.caption}</em></figcaption><button type="button" onClick={() => setSelectedPhoto(null)} aria-label="Đóng"><X size={18} /></button></motion.figure></motion.div>}</AnimatePresence>
    <AnimatePresence>{showNote && <motion.div className="note-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowNote(false)}><motion.form className="note-card" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 18 }} onClick={(event) => event.stopPropagation()} onSubmit={saveNote}><button className="close-modal" type="button" onClick={() => setShowNote(false)} aria-label="Đóng"><X size={18} /></button><p className="section-kicker"><Heart size={12} fill="currentColor" /> leave a birthday note</p><h2>Viết một điều<br /><em>để giữ lại.</em></h2><textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="Một lời chúc dịu dàng..." maxLength={360} autoFocus /><p>Được lưu riêng trên thiết bị này.</p><button className="save-note" type="submit">Lưu lời chúc <Sparkles size={15} /></button></motion.form></motion.div>}</AnimatePresence>
    <AnimatePresence>{toast && <motion.p className="toast" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} onAnimationComplete={() => window.setTimeout(() => setToast(""), 2500)}>{toast}</motion.p>}</AnimatePresence>
  </main>;
}
